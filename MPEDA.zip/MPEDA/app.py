from flask import Flask, render_template, request, jsonify,json
from bardapi import Bard
import os
import re
import smtplib
import ssl
from email.message import EmailMessage
from googletrans import Translator


app = Flask(__name__)

def clean_seafood_text(seafood_text):
    cleaned_text = re.sub(r'\*{2,}', '', seafood_text)
    cleaned_text = re.sub(r'\[Image of [^\]]*\]', '', cleaned_text)

    cleaned_text = re.sub(r'\bbla\b.*?(\.|$)', '', cleaned_text, flags=re.DOTALL)
    cleaned_text = cleaned_text.replace('\n', '')
    return cleaned_text.strip()

os.environ['_BARD_API_KEY'] = 'eAg5N8t2fhjCedfZmokYViUKgDfVTlrtCl0ksPtcyRjeg5eVaWWs6MUpLbekngtBSfqAVA.'

chat_history1 = [
    {'question': 'What is your name?', 'answer': 'My name is ChatGPT.'},
    {'question': 'How does this work?', 'answer': 'I generate responses based on input.'},
]
chat_history_string1 = '\n\n'.join([f"Question: {entry['question']}\nAnswer: {entry['answer']}" for entry in chat_history1])

print(chat_history_string1)
print(type(chat_history_string1))

chat_history = []
chat_history_string = '\n\n'.join([f"Question: {entry['question']}\nAnswer: {entry['answer']}" for entry in chat_history])
print(chat_history_string)

Summaries = []


@app.route('/get_answer', methods=['POST'])
def get_answer():
    input_text = request.form['input_text']
    target_language = request.form['target_language']
    translator = Translator()

    answer = Bard().get_answer(input_text)['content']
    original=clean_seafood_text(answer)
    translation = translator.translate(original, dest=target_language)
    chat_history.append({'question':input_text, 'answer': original,'translation':translation})
    summary = f"Write a summary within 40 words about {answer}"
    Summaries.append(Bard().get_answer(summary)['content'])

    return render_template('after.html', chat_history=chat_history,input_text=input_text, translation=translation.text)

@app.route('/')
def index():
    return render_template('index.html')

result_string = ', '.join(Summaries)
print(type(result_string))

@app.route('/send_email', methods=['GET'])
def send_email():
    sender = 'srinjoydas566@gmail.com'
    password = 'pxer uuxr uylz xxwg'
    receiver = 'saikat02004@gmail.com'
    subject = 'TEST for mpeda'
    body = result_string

    em = EmailMessage()
    em['From'] = sender
    em['To'] = receiver
    em['Subject'] = subject
    em.set_content(body)

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL('smtp.gmail.com', port=465, context=context) as smtp:
        smtp.login(sender, password)
        smtp.sendmail(sender, receiver, em.as_string())
        




if __name__ == '__main__':
    app.run(debug=True)
